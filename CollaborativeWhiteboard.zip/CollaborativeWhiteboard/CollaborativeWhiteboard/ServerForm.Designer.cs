﻿namespace CollaborativeWhiteboard
{
    partial class ServerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBoard = new System.Windows.Forms.Panel();
            this.btn_connect = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_end = new System.Windows.Forms.Button();
            this.txt_receive = new System.Windows.Forms.TextBox();
            this.pnlServerPenColor = new System.Windows.Forms.Panel();
            this.btn_penColor = new System.Windows.Forms.Button();
            this.trk_penWidth = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.trk_penWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // panelBoard
            // 
            this.panelBoard.AutoSize = true;
            this.panelBoard.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelBoard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBoard.Location = new System.Drawing.Point(0, 0);
            this.panelBoard.Name = "panelBoard";
            this.panelBoard.Size = new System.Drawing.Size(1260, 622);
            this.panelBoard.TabIndex = 0;
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(89, 29);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_connect.Size = new System.Drawing.Size(103, 47);
            this.btn_connect.TabIndex = 1;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(198, 29);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 47);
            this.btn_clear.TabIndex = 2;
            this.btn_clear.Text = "CLEAR";
            this.btn_clear.UseVisualStyleBackColor = true;
            // 
            // btn_end
            // 
            this.btn_end.Location = new System.Drawing.Point(279, 29);
            this.btn_end.Name = "btn_end";
            this.btn_end.Size = new System.Drawing.Size(75, 47);
            this.btn_end.TabIndex = 3;
            this.btn_end.Text = "END";
            this.btn_end.UseVisualStyleBackColor = true;
            // 
            // txt_receive
            // 
            this.txt_receive.Location = new System.Drawing.Point(390, 29);
            this.txt_receive.Multiline = true;
            this.txt_receive.Name = "txt_receive";
            this.txt_receive.Size = new System.Drawing.Size(155, 47);
            this.txt_receive.TabIndex = 4;
            // 
            // pnlServerPenColor
            // 
            this.pnlServerPenColor.Location = new System.Drawing.Point(704, 29);
            this.pnlServerPenColor.Name = "pnlServerPenColor";
            this.pnlServerPenColor.Size = new System.Drawing.Size(142, 42);
            this.pnlServerPenColor.TabIndex = 5;
            // 
            // btn_penColor
            // 
            this.btn_penColor.Location = new System.Drawing.Point(571, 29);
            this.btn_penColor.Name = "btn_penColor";
            this.btn_penColor.Size = new System.Drawing.Size(127, 35);
            this.btn_penColor.TabIndex = 6;
            this.btn_penColor.Text = "Pen Color";
            this.btn_penColor.UseVisualStyleBackColor = true;
            this.btn_penColor.Click += new System.EventHandler(this.btn_penColor_Click_1);
            // 
            // trk_penWidth
            // 
            this.trk_penWidth.Location = new System.Drawing.Point(882, 31);
            this.trk_penWidth.Maximum = 20;
            this.trk_penWidth.Minimum = 1;
            this.trk_penWidth.Name = "trk_penWidth";
            this.trk_penWidth.Size = new System.Drawing.Size(104, 69);
            this.trk_penWidth.TabIndex = 7;
            this.trk_penWidth.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trk_penWidth.Value = 2;
            // 
            // ServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 622);
            this.Controls.Add(this.trk_penWidth);
            this.Controls.Add(this.btn_penColor);
            this.Controls.Add(this.pnlServerPenColor);
            this.Controls.Add(this.txt_receive);
            this.Controls.Add(this.btn_end);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_connect);
            this.Controls.Add(this.panelBoard);
            this.Name = "ServerForm";
            this.Text = "ServerForm";
            this.Load += new System.EventHandler(this.ServerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trk_penWidth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelBoard;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_end;
        private System.Windows.Forms.TextBox txt_receive;
        private System.Windows.Forms.Panel pnlServerPenColor;
        private System.Windows.Forms.Button btn_penColor;
        private System.Windows.Forms.TrackBar trk_penWidth;
    }
}