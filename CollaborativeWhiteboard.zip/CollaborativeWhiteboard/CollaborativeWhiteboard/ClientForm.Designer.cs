﻿namespace CollaborativeWhiteboard
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_connect = new System.Windows.Forms.Button();
            this.btn_end = new System.Windows.Forms.Button();
            this.btn_send = new System.Windows.Forms.Button();
            this.txt_receive = new System.Windows.Forms.TextBox();
            this.panelBoard = new System.Windows.Forms.Panel();
            this.txt_send = new System.Windows.Forms.TextBox();
            this.pnlPenColor = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(12, 12);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(83, 37);
            this.btn_connect.TabIndex = 0;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            // 
            // btn_end
            // 
            this.btn_end.Location = new System.Drawing.Point(13, 55);
            this.btn_end.Name = "btn_end";
            this.btn_end.Size = new System.Drawing.Size(82, 37);
            this.btn_end.TabIndex = 1;
            this.btn_end.Text = "End";
            this.btn_end.UseVisualStyleBackColor = true;
            // 
            // btn_send
            // 
            this.btn_send.Location = new System.Drawing.Point(483, 12);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(80, 43);
            this.btn_send.TabIndex = 2;
            this.btn_send.Text = "Send";
            this.btn_send.UseVisualStyleBackColor = true;
            // 
            // txt_receive
            // 
            this.txt_receive.Location = new System.Drawing.Point(101, 12);
            this.txt_receive.Multiline = true;
            this.txt_receive.Name = "txt_receive";
            this.txt_receive.Size = new System.Drawing.Size(149, 77);
            this.txt_receive.TabIndex = 3;
            // 
            // panelBoard
            // 
            this.panelBoard.Location = new System.Drawing.Point(100, 164);
            this.panelBoard.Name = "panelBoard";
            this.panelBoard.Size = new System.Drawing.Size(1030, 488);
            this.panelBoard.TabIndex = 4;
            // 
            // txt_send
            // 
            this.txt_send.Location = new System.Drawing.Point(316, 12);
            this.txt_send.Multiline = true;
            this.txt_send.Name = "txt_send";
            this.txt_send.Size = new System.Drawing.Size(137, 77);
            this.txt_send.TabIndex = 5;
            // 
            // pnlPenColor
            // 
            this.pnlPenColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPenColor.Location = new System.Drawing.Point(634, 12);
            this.pnlPenColor.Name = "pnlPenColor";
            this.pnlPenColor.Size = new System.Drawing.Size(145, 47);
            this.pnlPenColor.TabIndex = 5;
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 622);
            this.Controls.Add(this.pnlPenColor);
            this.Controls.Add(this.txt_send);
            this.Controls.Add(this.panelBoard);
            this.Controls.Add(this.txt_receive);
            this.Controls.Add(this.btn_send);
            this.Controls.Add(this.btn_end);
            this.Controls.Add(this.btn_connect);
            this.Name = "ClientForm";
            this.Text = "ClientForm";
            this.Load += new System.EventHandler(this.ClientForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Button btn_end;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.TextBox txt_receive;
        private System.Windows.Forms.Panel panelBoard;
        private System.Windows.Forms.TextBox txt_send;
        private System.Windows.Forms.Panel pnlPenColor;
    }
}