﻿using System;
using System.Drawing;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace CollaborativeWhiteboard
{
    public partial class ClientForm : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        private Thread receiveThread;
        private volatile bool keepReceiving = false;

        private const string SERVER_IP = "10.231.39.93";
        private const int PORT = 5000;

        public ClientForm()
        {
            InitializeComponent();

            // ensure panel is read-only (no mouse drawing)
            panelBoard.BackColor = Color.White;

            // wire buttons if not wired in designer
            btn_connect.Click += btn_connect_Click;
            btn_end.Click += btn_end_Click;
            btn_send.Click += btn_send_Click;
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            // You can add any initialization code here if needed.
        }
        
        private void btn_connect_Click(object sender, EventArgs e)
        {
            try
            {
                client = new TcpClient(SERVER_IP, PORT);
                stream = client.GetStream();
                keepReceiving = true;
                receiveThread = new Thread(ReceiveData) { IsBackground = true };
                receiveThread.Start();

                AppendLine("Connected to server.");
            }
            catch (Exception ex)
            {
                AppendLine("Connect error: " + ex.Message);
            }
        }

        private void ReceiveData()
        {
            byte[] buffer = new byte[1024];
            var sb = new StringBuilder();

            while (keepReceiving)
            {
                int bytesRead = 0;
                try
                {
                    bytesRead = stream.Read(buffer, 0, buffer.Length);
                }
                catch
                {
                    keepReceiving = false;
                    break;
                }

                if (bytesRead == 0)
                {
                    keepReceiving = false;
                    break;
                }

                sb.Append(Encoding.ASCII.GetString(buffer, 0, bytesRead));
                string content = sb.ToString();
                int idx;
                while ((idx = content.IndexOf('\n')) != -1)
                {
                    string line = content.Substring(0, idx).Trim();
                    content = content.Substring(idx + 1);
                    if (!string.IsNullOrEmpty(line))
                    {
                        ProcessServerMessage(line);
                    }
                }

                sb.Clear();
                sb.Append(content);
            }

            AppendLine("Disconnected from server.");
        }

        private void ProcessServerMessage(string line)
        {
            // Handle "L;x1;y1;x2;y2;width;argb" and "CLEAR"
            if (line.StartsWith("L;"))
            {
                var parts = line.Split(';');
                if (parts.Length >= 7)
                {
                    if (!int.TryParse(parts[1], out int x1)) return;
                    if (!int.TryParse(parts[2], out int y1)) return;
                    if (!int.TryParse(parts[3], out int x2)) return;
                    if (!int.TryParse(parts[4], out int y2)) return;
                    if (!float.TryParse(parts[5], out float w)) return;
                    if (!int.TryParse(parts[6], out int argb)) return;

                    Color c = Color.FromArgb(argb);

                    // draw on UI thread
                    if (InvokeRequired)
                    {
                        BeginInvoke((Action)(() => DrawLineOnBoard(x1, y1, x2, y2, w, c)));
                    }
                    else
                    {
                        DrawLineOnBoard(x1, y1, x2, y2, w, c);
                    }
                }
            }
            else if (line.StartsWith("PENCOLOR;"))
            {
                string[] parts = line.Split(';');
                if (parts.Length >= 2)
                {
                    int argb;
                    if (!int.TryParse(parts[1], out argb)) return;
                    Color c = Color.FromArgb(argb);

                    // update a small UI panel to show current pen color (pnlPenColor)
                    if (this.InvokeRequired)
                    {
                        this.BeginInvoke((Action)(() =>
                        {
                            if (this.Controls.ContainsKey("pnlPenColor"))
                            {
                                System.Windows.Forms.Panel pnl = (System.Windows.Forms.Panel)this.Controls["pnlPenColor"];
                                pnl.BackColor = c;
                            }
                        }));
                    }
                    else
                    {
                        if (this.Controls.ContainsKey("pnlPenColor"))
                        {
                            System.Windows.Forms.Panel pnl = (System.Windows.Forms.Panel)this.Controls["pnlPenColor"];
                            pnl.BackColor = c;
                        }
                    }
                }
            }
            else if (line.StartsWith("PENWIDTH;"))
            {
                string[] parts = line.Split(';');
                if (parts.Length >= 2)
                {
                    float w;
                    if (float.TryParse(parts[1], out w))
                    {
                        // if you store client-side pen width for drawing UI, set it here
                        // e.g., clientPen.Width = w;
                    }
                }
            }
            else if (line == "CLEAR")
            {
                if (InvokeRequired) BeginInvoke((Action)(() => panelBoard.Refresh()));
                else panelBoard.Refresh();
            }
            else
            {
                // any other messages just display in log (optional)
                AppendLine("Server: " + line);
            }
        }

        private void DrawLineOnBoard(int x1, int y1, int x2, int y2, float width, Color color)
        {
            using (Graphics g = panelBoard.CreateGraphics())
            using (var p = new Pen(color, width) { StartCap = System.Drawing.Drawing2D.LineCap.Round, EndCap = System.Drawing.Drawing2D.LineCap.Round })
            {
                g.DrawLine(p, x1, y1, x2, y2);
            }
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            string message = txt_send.Text.Trim();
            if (string.IsNullOrEmpty(message)) return;

            try
            {
                var data = Encoding.ASCII.GetBytes(message + "\n");
                stream.Write(data, 0, data.Length);
                AppendLine("You: " + message);
                txt_send.Clear();
            }
            catch (Exception ex)
            {
                AppendLine("Send error: " + ex.Message);
            }
        }

        private void btn_end_Click(object sender, EventArgs e)
        {
            Disconnect();
            this.Close();
        }

        private void Disconnect()
        {
            keepReceiving = false;
            try { stream?.Close(); } catch { }
            try { client?.Close(); } catch { }
        }

        private void AppendLine(string text)
        {
            if (InvokeRequired)
            {
                BeginInvoke((Action)(() => AppendLine(text)));
                return;
            }

            try
            {
                var lines = txt_receive.Lines;
                var newLines = new string[lines.Length + 1];
                for (int i = 0; i < lines.Length; i++) newLines[i] = lines[i];
                newLines[lines.Length] = text;
                txt_receive.Lines = newLines;
            }
            catch
            {
                txt_receive.AppendText(text + Environment.NewLine);
            }
        }
    }
}
