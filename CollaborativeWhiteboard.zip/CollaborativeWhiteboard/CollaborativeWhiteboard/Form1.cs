﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CollaborativeWhiteboard
{
    public partial class Form1 : Form
    {
        private bool isDrawing = false;
        private Point lastPoint = Point.Empty;
        private Pen pen;

        public Form1()
        {
            InitializeComponent();
            // Initialize pen (you can change color or thickness)
            pen = new Pen(Color.Black, 4);

            // Hook mouse events for panel
            panelBoard.MouseDown += panelBoard_MouseDown;
            panelBoard.MouseMove += panelBoard_MouseMove;
            panelBoard.MouseUp += panelBoard_MouseUp;

            // Optional: give the panel a white background
            panelBoard.BackColor = Color.White;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            pen?.Dispose();
            base.OnFormClosing(e);
        }

        private void panelBoard_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            // Start a new stroke
            isDrawing = true;
            lastPoint = e.Location;

            // Keep receiving events even if the cursor/finger leaves the panel
            panelBoard.Capture = true;
        }

        private void panelBoard_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isDrawing) return;        // only draw while the button is pressed

            // Defensive: if lastPoint is empty, initialize it
            if (lastPoint == Point.Empty) lastPoint = e.Location;

            using (Graphics g = panelBoard.CreateGraphics())
            {
                g.DrawLine(pen, lastPoint, e.Location);
            }

            lastPoint = e.Location;
        }

        private void panelBoard_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            isDrawing = false;
            lastPoint = Point.Empty;
            panelBoard.Capture = false;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            // Simple: force the panel to repaint itself (background is white),
            // which removes any temporary CreateGraphics drawing.
            panelBoard.Refresh();
        }

        private void btn_microphone_Click(object sender, EventArgs e)
        {

        }

        private void btn_rectangle_Click(object sender, EventArgs e)
        {
        }
    }
}
