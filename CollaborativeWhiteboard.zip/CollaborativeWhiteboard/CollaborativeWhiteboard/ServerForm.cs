﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace CollaborativeWhiteboard
{
    public partial class ServerForm : Form
    {
        // networking
        private TcpListener server;
        private volatile bool serverRunning = false;
        private Thread acceptThread;
        private readonly List<TcpClient> clients = new List<TcpClient>();
        private readonly object clientsLock = new object();
        private const int PORT = 5000;

        // drawing (kept from your code)
        private bool isDrawing = false;
        private Point lastPoint = Point.Empty;
        private Pen pen;

        public ServerForm()
        {
            InitializeComponent();

            pen = new Pen(Color.Black, 5);

            panelBoard.MouseDown += panelBoard_MouseDown;
            panelBoard.MouseMove += panelBoard_MouseMove;
            panelBoard.MouseUp += panelBoard_MouseUp;

            panelBoard.BackColor = Color.White;

            // wire simple buttons if not wired in designer
            btn_connect.Click += btn_connect_Click;
            btn_clear.Click += btn_clear_Click;
            btn_end.Click += btn_end_Click;
            btn_penColor.Click += btn_penColor_Click;

        }
        private void trk_penWidth_Scroll(object sender, EventArgs e)
        {
            pen.Width = trk_penWidth.Value;
            string msg = string.Format("PENWIDTH;{0}\n", pen.Width);
            Broadcast(msg);
        }

        private void ServerForm_Load(object sender, EventArgs e)
        {
            // You can initialize things here if needed, or leave empty if not required.
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            ShutdownServer();
            pen?.Dispose();
            base.OnFormClosing(e);
        }

        // --- UI drawing handlers (same simple style) ---
        private void panelBoard_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            isDrawing = true;
            lastPoint = e.Location;
            panelBoard.Capture = true;
        }

        private void panelBoard_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isDrawing) return;
            if (lastPoint == Point.Empty) lastPoint = e.Location;

            // draw locally with your original approach
            using (Graphics g = panelBoard.CreateGraphics())
            {
                g.DrawLine(pen, lastPoint, e.Location);
            }

            // build message and broadcast
            // Format: L;x1;y1;x2;y2;width;argb\n
            string msg = string.Format("L;{0};{1};{2};{3};{4};{5}\n",
                                       lastPoint.X, lastPoint.Y,
                                       e.Location.X, e.Location.Y,
                                       pen.Width,
                                       pen.Color.ToArgb());

            Broadcast(msg);

            lastPoint = e.Location;
        }

        private void panelBoard_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            isDrawing = false;
            lastPoint = Point.Empty;
            panelBoard.Capture = false;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            panelBoard.Refresh();
            Broadcast("CLEAR\n");
        }

        // ---------- Server control ----------
        private void btn_connect_Click(object sender, EventArgs e)
        {
            StartServer(PORT);
        }

        private void StartServer(int port)
        {
            if (serverRunning) return;
            try
            {
                server = new TcpListener(IPAddress.Any, port);
                server.Start();
                serverRunning = true;
                AppendLine($"Server started on port {port}.");

                acceptThread = new Thread(AcceptLoop) { IsBackground = true };
                acceptThread.Start();
            }
            catch (Exception ex)
            {
                AppendLine("Start error: " + ex.Message);
            }
        }

        private void AcceptLoop()
        {
            try
            {
                while (serverRunning)
                {
                    TcpClient tcp = server.AcceptTcpClient(); // blocking
                    if (!serverRunning)
                    {
                        tcp.Close();
                        break;
                    }

                    lock (clientsLock) clients.Add(tcp);

                    AppendLine($"Client connected: {tcp.Client.RemoteEndPoint} (total: {ClientCount()})");

                    // Start a monitor thread for this client to detect disconnection and any messages
                    Thread t = new Thread(HandleClient) { IsBackground = true };
                    t.Start(tcp);
                }
            }
            catch (SocketException)
            {
                // listener stopped
            }
            catch (Exception ex)
            {
                AppendLine("AcceptLoop error: " + ex.Message);
            }
        }

        private void HandleClient(object obj)
        {
            var tcp = obj as TcpClient;
            if (tcp == null) return;

            NetworkStream ns = null;
            try
            {
                ns = tcp.GetStream();
                byte[] buffer = new byte[1024];
                var sb = new StringBuilder();

                while (serverRunning && tcp.Connected)
                {
                    int bytesRead = 0;
                    try
                    {
                        bytesRead = ns.Read(buffer, 0, buffer.Length);
                    }
                    catch
                    {
                        break;
                    }

                    if (bytesRead == 0) break;

                    sb.Append(Encoding.ASCII.GetString(buffer, 0, bytesRead));
                    string content = sb.ToString();
                    int idx;
                    while ((idx = content.IndexOf('\n')) != -1)
                    {
                        string line = content.Substring(0, idx).Trim();
                        content = content.Substring(idx + 1);
                        if (!string.IsNullOrEmpty(line))
                        {
                            // handle simple client commands; if client sends "exit" we disconnect
                            if (line.Equals("exit", StringComparison.OrdinalIgnoreCase))
                            {
                                try { tcp.Close(); } catch { }
                                break;
                            }
                            else
                            {
                                // optionally display client messages
                                AppendLine($"Client {tcp.Client.RemoteEndPoint}: {line}");
                            }
                        }
                    }

                    sb.Clear();
                    sb.Append(content);
                }
            }
            catch (Exception ex)
            {
                AppendLine("Client handler error: " + ex.Message);
            }
            finally
            {
                try { ns?.Close(); } catch { }
                try { tcp?.Close(); } catch { }

                lock (clientsLock)
                {
                    if (clients.Contains(tcp)) clients.Remove(tcp);
                }

                AppendLine($"Client disconnected (total: {ClientCount()})");
            }
        }

        // ---------- Broadcast helper ----------
        private void Broadcast(string message)
        {
            byte[] data = Encoding.ASCII.GetBytes(message);
            List<TcpClient> remove = null;

            lock (clientsLock)
            {
                foreach (var c in clients)
                {
                    try
                    {
                        if (c != null && c.Connected)
                        {
                            var s = c.GetStream();
                            s.Write(data, 0, data.Length);
                            s.Flush();
                        }
                        else
                        {
                            if (remove == null) remove = new List<TcpClient>();
                            remove.Add(c);
                        }
                    }
                    catch
                    {
                        if (remove == null) remove = new List<TcpClient>();
                        remove.Add(c);
                    }
                }

                if (remove != null)
                {
                    foreach (var r in remove)
                    {
                        try { r.Close(); } catch { }
                        clients.Remove(r);
                    }
                }
            }
        }
        private void btn_penColor_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            System.Windows.Forms.DialogResult dr = dlg.ShowDialog();
            if (dr == DialogResult.OK)
            {
                // set server pen color (this is the canonical color)
                pen.Color = dlg.Color;

                // broadcast the new color to clients so they can update UI state
                string msg = string.Format("PENCOLOR;{0}\n", pen.Color.ToArgb());
                Broadcast(msg);

                // optional: show on server UI if you add a small panel, e.g. pnlServerPenColor
                try
                {
                    if (this.InvokeRequired)
                    {
                        this.BeginInvoke((Action)(() =>
                        {
                            if (this.Controls.ContainsKey("pnlServerPenColor"))
                            {
                                System.Windows.Forms.Panel pnl = (System.Windows.Forms.Panel)this.Controls["pnlServerPenColor"];
                                pnl.BackColor = pen.Color;
                            }
                        }));
                    }
                    else
                    {
                        if (this.Controls.ContainsKey("pnlServerPenColor"))
                        {
                            System.Windows.Forms.Panel pnl = (System.Windows.Forms.Panel)this.Controls["pnlServerPenColor"];
                            pnl.BackColor = pen.Color;
                        }
                    }
                }
                catch
                {
                    // ignore UI update errors
                }
            }
        }

        private int ClientCount()
        {
            lock (clientsLock) return clients.Count;
        }

        private void btn_end_Click(object sender, EventArgs e)
        {
            ShutdownServer();
            AppendLine("Server closed.");
            this.Close();
        }

        private void ShutdownServer()
        {
            serverRunning = false;
            try { server?.Stop(); } catch { }

            lock (clientsLock)
            {
                foreach (var c in clients)
                {
                    try { c.Close(); } catch { }
                }
                clients.Clear();
            }

            try
            {
                if (acceptThread != null && acceptThread.IsAlive) acceptThread.Join(200);
            }
            catch { }
        }

        // UI helper similar to your earlier approach
        private void AppendLine(string text)
        {
            if (InvokeRequired)
            {
                BeginInvoke((Action)(() => AppendLine(text)));
                return;
            }

            try
            {
                var lines = txt_receive.Lines;
                var newLines = new string[lines.Length + 1];
                for (int i = 0; i < lines.Length; i++) newLines[i] = lines[i];
                newLines[lines.Length] = text;
                txt_receive.Lines = newLines;
            }
            catch
            {
                txt_receive.AppendText(text + Environment.NewLine);
            }
        }

        private void btn_penColor_Click_1(object sender, EventArgs e)
        {

        }
    }
}
